#define WINDOWS_DATA_EVENT 0
//Includes data in
#define WINDOWS_FOCUS_EVENT 1
//Includes only code, data points to zero
#define WINDOWS_MOUSE_LEFT_BUTTON_DOWN 2
#define WINDOWS_MOUSE_RIGHT_BUTTON_DOWN 3
#define WINDOWS_MOUSE_MIDDLE_BUTTON_DOWN 4
//Mouse down
#define WINDOWS_MOUSE_LEFT_BUTTON_CLICK 5
#define WINDOWS_MOUSE_RIGHT_BUTTON_CLICK 6
#define WINDOWS_MOUSE_MIDDLE_BUTTON_CLICK 7
//Mouse click eq to DOWN, but may be used
#define WINDOWS_MOUSE_LEFT_BUTTON_UP 8
#define WINDOWS_MOUSE_RIGHT_BUTTON_UP 9
#define WINDOWS_MOUSE_MIDDLE_BUTTON_UP 10
//Mouse button up
#define WINDOWS_KEY_DOWN 11
#define WINDOWS_KEY_UP 12
//Keyboard
#define WINDOWS_DEFOCUS_EVENT 13
//Unfocus



