
void ____start()
{	
	_main();
}

