#include "includes\executable.c"
#include "includes\stdio.h"
void _main()
{
	kprintf("Program runned!\n");
	for(;;);
}